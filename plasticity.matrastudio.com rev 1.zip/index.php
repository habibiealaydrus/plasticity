<?php include('mainlayout/header.php') ?>

<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner ">
        <div class="carousel-item active">
            <img src="img/carousel/carousel1.png" class="d-block w-100" alt="karusel 1">
        </div>
        <div class="carousel-item">
            <img src="img/carousel/carousel2.png" class="d-block w-100" alt="karusel 2">
        </div>
        <div class="carousel-item">
            <img src="img/carousel/carousel3.png" class="d-block w-100" alt="karusel 3">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<div class="container-fluid text-center">
    <div class="row fade-in">
        <div class="col-sm-8">
            <div>
                <img src="img/mainimage2.png" class="img-fluid gambar">
            </div>
        </div>
        <div class="col-sm-4 maintext">
            <p class="artikel gambar" style="text-align: justify;">
                <strong>Plasti(c)ity Tree </strong> menggambarkan transisi Jakarta sebagai ibu kota Indonesia sekarang menuju Ibu Kota Nusantara (IKN) di masa depan. Seperti sebuah
                pohon yang bertumbuh, memiliki akar yang kuat, memiliki cabang yang menjulang, dan bergenerasi menjadi lebih baik. Jakarta sebagai salah satu
                landasan untuk IKN, terus mempersiapkan diri menghadapi tantangan masa depan, tidak hanya pada kualitas pembangunan fisik, tetapi juga perubahan
                non fisik seperti; tatanan sosial masyarakat yang lebih baik, perkuatan identitas budaya, dan pelaksanaan aspek keberlanjutan.
                Untuk mewujudkan tujuan tersebut, harus didukung kemampuan untuk beradaptasi, kemampuan untuk menyesuaikan diri menghadapi tantangan
                dan kebutuhan di masa depan, hal ini dimetaforakan pada sifat plastisitas material, plasticity, yaitu kemampuan suatu benda atau material untuk
                mengalami perubahan bentuk tanpa mengalami kerusakan, contohnya sifat material plastik. Penerapannya diaplikasikan pada bentuk instalasi yang
                menyerupai bentuk pohon dengan menggunakan geometri yang dinamis dan tidak kaku. Instalasi berbahan limbah plastik yang didaur ulang sebagai
                kampanye gerakan ramah lingkungan, dan sarana edukasi keberlanjutan untuk masyarakat umum.
            </p>
        </div>
    </div>
    <div class="row fade-in" style="background-color: whitesmoke;">
        <div class="col-sm-6 maintext">
            <p class="artikel" style="text-align: justify;">
                Material menggunakan panel upcycle HDPE dengan tebal 2-3 mm dari daur ulang tutup botol plastik, yang difabrikasi menggunakan lasercuting menjadi
                138 pieces interlocking strip, setiap strip dihubungkan menggunakan baut rivet. karakter strip yang fleksibel namun kaku memungkinkan instalasi
                untuk berdiri sendiri tanpa bantuan struktur tambahan. Beratnya yang ringan memungkinkan untuk dirakit menjadi beberapa bagian di workshop dan
                disatukan di lokasi instalasi.
            </p>
        </div>
        <div class="col-sm-6">
            <img src="img/fitur2.png" class="img-fluid gambar">
        </div>
    </div>
    <div class="container-fluid video">
        <iframe width="100%" height="600px" src="https://www.youtube.com/embed/IMvG6CvoPY0?si=PUyPl3nnN7chR6XC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
    <div class=" row fade-in" style="background-color: whitesmoke;">
        <div class="col-sm-6">
            <img src="img/image-credit2.png" class="img-fluid gambar">
        </div>
        <div class="col-sm-6">
            <p class="text-start" style="padding-top: 5%">
                <strong>Desain & Konsep</strong></br>
                <span>
                    Matra Studio + Universitas Multimedia Nusantara
                    Rizki Tridamayanti Siregar, Yasser Hafizs, Erika Angelina, Alvioletta Geraldine, M. Cahya Mulya Daulay,
                    S.Sn., M.Ds., Rahmi Elsa Diana, S.T., M.T.
                </span></br>
                <strong>Kolaborator</strong></br>
                <span>
                    Mortier, Yayasan Wings Group
                    Mendy, Irene, Retno, Jason, Gita, Michi, Sekar, Ariesta, Syifa, dan Mas Mas
                </span></br>
                <strong>Tim Fabrikasi</strong></br>
                <span>
                    Chaeri Abdillah, Gema Ibrahim Ahmada, Sangkakala P. Indo, Naya Kamila, Farah Artanti, Christy, Silvia,
                    Wenzel, Rapha, Reno, Alicia Phannely, Ayu Nabilah, Shafira Ardhani, Pramudya Abimanyu, Donny
                    Aditya Natanael, Rafa Naufal Adli, Nurul Izzah Saidah, Adetia Widiani, Helen Agustini, Theresia Winna
                </span></br>
                <strong>Video Editing</strong></br>
                <span>
                    Rafiandy Bimo Nugroho, Bhagaskara Tri Atmojo
                </span></br>
                <strong>Web Design</strong></br>
                <span>
                    Habibi Alaydrus
                </span></br>
            </p>
        </div>
    </div>
    <div class="row fade-in">
        <div class="d-flex justify-content-center">
            <div class="p-1">
                <img src="img/logomatrastudio.png" width="50%" class="image-fluid">
            </div>
        </div>

        <center>
            <p>
                <Strong>PARTNERS</Strong>
            </p>
        </center>
        <div class="d-flex justify-content-center">
            <div class="p-2">
                <img src="img/logo mortier.png" width="50%" class="image-fluid">

            </div>
            <div class="p-2">
                <img src="img/logo umn.png" width="50%" class="image-fluid">
            </div>
            <div class="p-2">
                <img src="img/logo yaysan wings.png" width="50%" class="image-fluid">
            </div>
        </div>

    </div>
</div>
<?php include("mainlayout/footer.php") ?>